package spse.creeperface.battleships.server.network.protocol.packet;

/**
 * @author CreeperFace
 */
public class DataPacket {
}
