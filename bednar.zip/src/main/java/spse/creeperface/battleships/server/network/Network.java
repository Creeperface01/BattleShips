package spse.creeperface.battleships.server.network;

/**
 * @author CreeperFace
 */
public class Network {
}
