package spse.creeperface.battleships.server;

/**
 * @author CreeperFace
 */
public class Server {
}
