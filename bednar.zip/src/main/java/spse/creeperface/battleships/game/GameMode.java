package spse.creeperface.battleships.game;

/**
 * @author CreeperFace
 */
public enum GameMode {
    SINGLE,
    MULTI,
    MULTI_LOCAL
}
