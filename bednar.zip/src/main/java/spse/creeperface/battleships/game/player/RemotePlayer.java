package spse.creeperface.battleships.game.player;

/**
 * @author CreeperFace
 */
public class RemotePlayer {
}
