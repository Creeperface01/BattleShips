package spse.creeperface.battleships.game.statistics;

/**
 * @author CreeperFace
 */
public enum Stat {
    HIT,
    MISS,
    WIN
}
