package spse.creeperface.battleships.game.map;

/**
 * @author CreeperFace
 */
public enum Tile {
    UNKNOWN,
    MARKED,
    HIT,
    SHIP,
}
