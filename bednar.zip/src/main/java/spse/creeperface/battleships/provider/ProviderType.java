package spse.creeperface.battleships.provider;

/**
 * @author CreeperFace
 */
public enum ProviderType {
    JSON,
    MYSQL,
    SQLITE,
    YAML;
}