package spse.creeperface.battleships.provider;

/**
 * @author CreeperFace
 */
public class JsonProvider {
}
